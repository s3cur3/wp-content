<?php
/*
Template Name: All Attorneys
*/
?>
<?php get_template_part('templates/page', 'header'); ?>
<?php get_template_part('templates/content', 'attorneys'); ?>
