Theme Name:         The Modern Law Firm
Theme URI:          http://conversioninsights.net/free-wordpress-themes-law-firms/
Description:        A clean, modern, responsive theme just for lawyers & law firms.
Version:            6.5.1
Author:             Tyler Young
Author URI:         http://conversioninsights.net/tyler-young

License:            GPLv2
License URI:        http://www.gnu.org/licenses/gpl-2.0.html




For full documentation, open this theme's "docs" directory and open the "modern-law-firm-documentation.html" file.

