(function($) {
    $(document).ready(function () {
        function getURLParameter(name) {
            return decodeURIComponent((new RegExp('[?|&]' + name + '=' + '([^&;]+?)(&|#|;|$)').exec(location.search)||[,""])[1].replace(/\+/g, '%20'))||null;
        }

        var colorTheme = getURLParameter('color');
        if( colorTheme ) {
            var queryString = "color=" + colorTheme;

            $('a').each(function() {
                var href = $(this).attr('href');

                if( href && !$(this).hasClass('no-color-link') ) {
                    href += (href.match(/\?/) ? '&' : '?') + queryString;
                    $(this).attr('href', href);
                }
            });
        }



        var layoutSelect = $('#layout');
        if( $('div.wrap').hasClass('container-full-width') ) {
            layoutSelect.val('full');
        } else {
            layoutSelect.val('normal');
        }

        layoutSelect.change(function() {
            console.log("switching");
            console.log($(this).val());
            console.log("Val is normal?");
            console.log(( $(this).val() == 'normal' ));
            var wrap = $('div.wrap');
            if( $(this).val() == 'normal' ) {
                wrap.addClass('container');
                wrap.removeClass('container-full-width');
            } else {
                wrap.addClass('container-full-width');
                wrap.removeClass('container');
            }
        });

    });
})(jQuery);
