
Envato Marketplace Author Image Templates by pixelentity

-------------------------------------------------

These image templates maybe used for personal or commercial projects without restriction. Attribution is appreciated but not required. These psd files may NOT be sold.

To inser your image:

1. Open with photoshop (CS3+)
2. Open the "screenshots" layer, it will be marked with a red color.
3. You will see a layer named "Add your Image in Here".
4. Paste your image into this layer.
5. If your image is too large, resize it using transform tool.
6. The transform tool can be found under Edit>Transform or by pressing Ctrl+T when the image layer is selected.
7. The image you inserted will be cropped to match the template no matter if its larger then the template's area.


Reflections:

Some of the templates contain reflections.To insert your image into the reflection do the following:
1. Follow the same procedure as above for inserting the normal image.
2. This time however simply flip another copy of your image and paste it into the layer marker "add your reflection image here". 
3. Then resize to match the original image.


And thats it.

These image templates are brought to you by pixelentity
http://pixelentity.com